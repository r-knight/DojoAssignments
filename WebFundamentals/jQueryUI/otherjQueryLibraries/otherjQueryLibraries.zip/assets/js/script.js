$(function(){
	
	var pp = $('#submit').pointPoint();
	
	// To destroy it, call the destroy method:
	// pp.destroyPointPoint(); 	
	
});