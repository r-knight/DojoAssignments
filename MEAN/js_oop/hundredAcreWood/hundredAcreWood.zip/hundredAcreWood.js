var tigger = {character: "Tigger"};
var pooh = {character: "Winnie the Pooh"};
var piglet = {character: "Piglet"};
var bees = {character: "Bees"};
var owl = {character: "Owl"};
var christopher = {character: "Christopher Robin"};
var rabbit = {character: "Rabbit"};
var gopher = {character: "Gopher"};
var kanga = {character: "Kanga"};
var eeyore = {character: "Eeyore"};
var heffalumps = {character: "Heffalumps"};

tigger.north = pooh;
pooh.south = tigger;
pooh.west = piglet;
pooh.east = bees;
pooh.north = christopher;
bees.west = pooh;
bees.north = rabbit;
piglet.east = pooh;
piglet.north = owl;
owl.south = piglet;
owl.east = christopher;
christopher.south = pooh;
christopher.west = owl;
christopher.east = rabbit;
christopher.north = kanga;
rabbit.south = bees;
rabbit.west = christopher;
rabbit.east = gopher;
gopher.west = rabbit;
kanga.south = christopher;
kanga.north = eeyore;
eeyore.south = kanga;
eeyore.east = heffalumps;
heffalumps.west = eeyore;

var player = {
    location: tigger
}
function move(direction){
	if (direction in player.location){
		player.location = player.location[direction];
		console.log("You are now at " + player.location["character"] + "'s house");
	}
	else{
		console.log ("You may not go that way!");
	}
}