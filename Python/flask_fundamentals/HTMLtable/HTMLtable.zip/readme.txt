responsive-card-table css found on foundation.zurb.com
https://foundation.zurb.com/building-blocks/blocks/responsive-card-table.html