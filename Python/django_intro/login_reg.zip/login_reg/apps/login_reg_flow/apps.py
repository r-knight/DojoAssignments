from django.apps import AppConfig


class FirstAppConfig(AppConfig):
    name = 'login_reg_flow'
