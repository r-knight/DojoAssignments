from django.apps import AppConfig


class DojoNinjasConfig(AppConfig):
    name = 'dojo_ninjas'
