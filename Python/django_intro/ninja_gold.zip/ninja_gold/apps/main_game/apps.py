from django.apps import AppConfig


class MainGameConfig(AppConfig):
    name = 'main_game'
