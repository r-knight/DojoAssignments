from django.apps import AppConfig


class WordsConfig(AppConfig):
    name = 'words'
