from django.apps import AppConfig


class FirstAppConfig(AppConfig):
    name = 'book_reviews'
