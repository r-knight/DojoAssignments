from django.apps import AppConfig


class TimeDisplayConfig(AppConfig):
    name = 'time_display'
