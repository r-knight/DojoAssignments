from django.apps import AppConfig


class PurchaseFlowConfig(AppConfig):
    name = 'purchase_flow'
