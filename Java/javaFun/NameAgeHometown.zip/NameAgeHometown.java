public class NameAgeHometown {
    public static void main(String[] args) {
        System.out.println("My name is Ryan");
        System.out.println("My name is age is between 18 and 118");
        System.out.println("My hometown is Middle-of-Nowhere, USA");
    }
}